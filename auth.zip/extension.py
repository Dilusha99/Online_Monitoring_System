from flask_sqlalchemy import SQLAlchemy
import pytz

db = SQLAlchemy()
colombo_tz = pytz.timezone("Asia/Colombo")
